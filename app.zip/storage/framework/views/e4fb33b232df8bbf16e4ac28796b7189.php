<?php $__env->startSection('title', 'Fizzify - Portofolio'); ?>
<?php $__env->startSection('body_class', 'page-portfolio'); ?>

<?php $__env->startSection('content'); ?>
<main class="portfolio">
    <section>
        <h1 class="portfolio__title">Our<br>Portofolio</h1>

        <div class="portfolio__cards">
            <div class="glass">
                Intip rekam jejak momen seru dan kesegaran nyata bersama Fizzify! Dari aktivitas olahraga,
                nongkrong bareng teman, hingga selebrasi santai di kolam renang, Fizzify selalu hadir
                mewarnai setiap harimu.
            </div>
            <div class="glass">
                Koleksi visual dan kampanye kreatif yang menampilkan semangat penuh warna Fizzify. Kami
                menghadirkan kombinasi rasa unik dan energi positif yang menyatu sempurna dengan gaya
                hidup aktif masa kini.
            </div>
        </div>
    </section>

    <section class="gallery">
        <?php $__currentLoopData = range(1, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button class="gallery__item" type="button" data-lightbox="<?php echo e(asset('assets/img/portfolio-'.$n.'.webp')); ?>" aria-label="Lihat foto <?php echo e($n); ?>">
                <img src="<?php echo e(asset('assets/img/portfolio-'.$n.'.webp')); ?>" alt="Portofolio Fizzify <?php echo e($n); ?>" loading="lazy">
            </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\fizziy\fizzify-laravel\resources\views/portfolio.blade.php ENDPATH**/ ?>