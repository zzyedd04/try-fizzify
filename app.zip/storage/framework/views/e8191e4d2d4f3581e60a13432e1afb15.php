<?php $__env->startSection('title', 'Fizzify - Home'); ?>
<?php $__env->startSection('body_class', 'page-home'); ?>

<?php $__env->startSection('content'); ?>
<main class="hero">
    <div class="hero__content">
        <h1 class="hero__title">Pop the fizz<br>feel the fun!</h1>

        <div class="hero__text glass">
            <p>
                Fizzify hadir buat bikin harimu makin berwarna dan penuh energi! Kami memadukan kesegaran soda
                dengan varian rasa buah favoritmu, siap nemenin setiap momen santai, kumpul bareng teman, sampai
                petualangan serumu berikutnya. <strong>Pop the fizz and feel the fun!</strong>
            </p>
        </div>

        <a class="cta" href="<?php echo e(route('product')); ?>">
            <span>Explore our product</span>
            <?php echo $__env->make('partials.arrow', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </a>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\fizziy\fizzify-laravel\resources\views/home.blade.php ENDPATH**/ ?>