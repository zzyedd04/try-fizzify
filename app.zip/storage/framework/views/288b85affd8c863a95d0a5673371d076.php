<?php $__env->startSection('title', 'Fizzify - About'); ?>
<?php $__env->startSection('body_class', 'page-about'); ?>

<?php $__env->startSection('content'); ?>
<main class="hero">
    <div class="hero__content">
        <h1 class="hero__title">About us</h1>

        <div class="hero__text glass">
            <p>
                Fizzify lahir dari ide sederhana: menghadirkan minuman yang nggak cuma menghilangkan dahaga, tapi
                juga membawa keceriaan di setiap tegukan. Kami percaya bahwa setiap harimu berhak dirayakan dengan
                sesuatu yang menyegarkan dan penuh warna.
            </p>
            <p>
                Dengan memadukan rasa buah pilihan dan gelembung soda yang pas, Fizzify hadir dalam berbagai
                varian rasa unik yang siap menemani setiap momenmu&mdash;mulai dari fokus ngerjain tugas, nongkrong
                bareng teman, sampai santai di akhir pekan.
            </p>
        </div>

        <a class="cta" href="<?php echo e(route('portfolio')); ?>">
            <span>Explore our portofolio</span>
            <?php echo $__env->make('partials.arrow', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </a>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\fizziy\fizzify-laravel\resources\views/about.blade.php ENDPATH**/ ?>