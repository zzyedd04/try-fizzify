<?php $__env->startSection('title', 'Fizzify - Product'); ?>
<?php $__env->startSection('body_class', 'page-product'); ?>

<?php $__env->startSection('content'); ?>
<main class="product">
    <div class="shop-grid">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="pcard" style="--c: <?php echo e($p->color); ?>">
                <div class="pcard__img"><img src="<?php echo e($p->image_url); ?>" alt="<?php echo e($p->name); ?>"></div>
                <h3 class="pcard__name"><?php echo e($p->name); ?></h3>
                <p class="pcard__desc">&ldquo;<?php echo e($p->description); ?>&rdquo;</p>
                <span class="pcard__price"><?php echo e(rupiah($p->price)); ?></span>

                <?php if($p->stock < 1): ?>
                    <span class="pcard__buy is-soldout">Habis</span>
                <?php else: ?>
                    <?php if(auth()->guard()->check()): ?>
                        <button class="pcard__buy" type="button" data-buy
                                data-id="<?php echo e($p->id); ?>" data-name="<?php echo e($p->name); ?>" data-price="<?php echo e($p->price); ?>"
                                data-image="<?php echo e($p->image_url); ?>" data-stock="<?php echo e($p->stock); ?>">Buy</button>
                    <?php else: ?>
                        <a class="pcard__buy" href="<?php echo e(route('login', ['buy' => 1])); ?>">Buy</a>
                    <?php endif; ?>
                <?php endif; ?>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</main>

<?php if(auth()->guard()->check()): ?>
<div class="modal" id="checkout" hidden>
    <div class="modal__backdrop" data-close></div>
    <div class="pay" role="dialog" aria-modal="true" aria-labelledby="payTitle">
        <button class="pay__close" type="button" data-close aria-label="Tutup">&times;</button>

        <div class="pay__left">
            <h2 id="payTitle">Payment</h2>

            <form id="checkoutForm">
                <input type="hidden" name="product_id" id="payProductId">

                <div class="pay__head">
                    <span>Detail Pesanan</span>
                    <img src="<?php echo e(asset('assets/img/pay-cards.webp')); ?>" alt="Visa, Mastercard, AMEX, JCB">
                </div>

                <label>Nama Lengkap
                    <input type="text" name="customer_name" value="<?php echo e(auth()->user()->name); ?>" required maxlength="80">
                </label>
                <label>No. HP / WhatsApp
                    <input type="tel" name="phone" inputmode="tel" placeholder="08xxxxxxxxxx" required maxlength="20">
                </label>
                <label>Alamat / Lokasi
                    <input type="text" name="address" placeholder="Contoh: Banda Aceh, Meuraxa" required maxlength="200">
                </label>

                <div class="pay__qty">
                    <span>Jumlah</span>
                    <div class="stepper">
                        <button type="button" data-qty="-1" aria-label="Kurangi">&minus;</button>
                        <output id="qtyOut">1</output>
                        <button type="button" data-qty="1" aria-label="Tambah">+</button>
                    </div>
                </div>

                <p class="pay__note">
                    Metode bayar dipilih di langkah berikutnya: Kartu Kredit/Debit, Virtual Account, QRIS,
                    GoPay, ShopeePay, dan lainnya. Pembayaran diproses aman oleh Midtrans.
                </p>

                <div class="pay__due"><span>Due Today</span><strong id="dueOut">Rp. 0</strong></div>
                <button class="pay__buy" id="payBtn" type="submit">Buy Now</button>
            </form>
        </div>

        <div class="pay__right">
            <div class="pay__can"><img id="payImg" src="" alt=""></div>
            <h3 id="payName"></h3>
            <p id="payPrice"></p>
        </div>
    </div>
</div>

<div class="modal" id="paidOk" hidden>
    <div class="modal__backdrop" data-close></div>
    <div class="ok" role="alertdialog">
        <button type="button" data-close aria-label="Tutup">&times;</button>
        <strong>Payment Successful</strong>
        <span>Thank You</span>
        <a class="ok__link" href="<?php echo e(route('cart')); ?>">Lihat pesanan di Keranjang</a>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php if(auth()->guard()->check()): ?>
    <script>
        window.FZ = {
            checkoutUrl: <?php echo json_encode(route('checkout.store'), 15, 512) ?>,
            syncUrl: <?php echo json_encode(url('/checkout'), 15, 512) ?>,
            midtransReady: <?php echo json_encode($midtransReady, 15, 512) ?>,
        };
    </script>
    <?php if($midtransReady): ?>
        <script src="<?php echo e($snapJsUrl); ?>" data-client-key="<?php echo e($midtransClientKey); ?>"></script>
    <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\fizziy\fizzify-laravel\resources\views/product.blade.php ENDPATH**/ ?>