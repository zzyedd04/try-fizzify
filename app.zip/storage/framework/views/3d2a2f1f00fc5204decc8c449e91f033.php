<?php $__env->startSection('title', 'Fizzify - Log In'); ?>
<?php $__env->startSection('body_class', 'page-auth page-login'); ?>

<?php $__env->startSection('content'); ?>
<main class="auth" style="--bg: url('<?php echo e(asset('assets/img/bg-login.webp')); ?>')">
    <div class="auth-card">
        <div class="auth-card__photo" style="--photo: url('<?php echo e(asset('assets/img/bg-login.webp')); ?>')"></div>

        <div class="auth-card__main">
            <div class="auth-card__top">
                <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/img/logo-black.png')); ?>" alt="Fizzify"></a>
                <a class="pill-small" href="<?php echo e(route('admin.login')); ?>">Log In To Admin</a>
            </div>

            <form class="auth-form" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <h1>Log In</h1>

                <div class="inputs">
                    <input type="text" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username" autocomplete="username" required autofocus>
                    <input type="password" name="password" placeholder="Password" autocomplete="current-password" required>
                </div>

                <div class="or">or</div>
                <a class="btn-google" href="<?php echo e(route('google.redirect')); ?>">
                    <img src="<?php echo e(asset('assets/img/google.webp')); ?>" alt="">Sign in with Google
                </a>
                <button class="btn-primary" type="submit">Login</button>

                <p class="switch">Didn't have an account? <a href="<?php echo e(route('signup')); ?>">Sign Up</a></p>
                <p class="switch"><a href="<?php echo e(route('home')); ?>">&larr; Kembali ke Home</a></p>
            </form>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\fizziy\fizzify-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>