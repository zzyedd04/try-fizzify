<header class="nav">
    <a class="nav__logo" href="<?php echo e(route('home')); ?>" aria-label="Fizzify">
        <img class="logo-green" src="<?php echo e(asset('assets/img/logo-green.png')); ?>" alt="Fizzify">
        <img class="logo-black" src="<?php echo e(asset('assets/img/logo-black.png')); ?>" alt="Fizzify">
    </a>

    <nav class="nav__pill">
        <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'is-active' : ''); ?>">Home</a>
        <a href="<?php echo e(route('about')); ?>" class="<?php echo e(request()->routeIs('about') ? 'is-active' : ''); ?>">About</a>
        <a href="<?php echo e(route('product')); ?>" class="<?php echo e(request()->routeIs('product') ? 'is-active' : ''); ?>">Product</a>
        <a href="<?php echo e(route('portfolio')); ?>" class="<?php echo e(request()->routeIs('portfolio') ? 'is-active' : ''); ?>">Portofolio</a>
        <a href="<?php echo e(route('contact')); ?>" class="<?php echo e(request()->routeIs('contact') ? 'is-active' : ''); ?>">Contact</a>
    </nav>

    <div class="nav__auth">
        <?php $cartCount = auth()->check() ? auth()->user()->orders()->inCart()->count() : 0; ?>
        <a class="nav__cart <?php echo e(request()->routeIs('cart') ? 'is-active' : ''); ?>" href="<?php echo e(route('cart')); ?>" aria-label="Keranjang" title="Keranjang">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M6 7h12l-1 13H7L6 7Z"/>
                <path d="M9 7a3 3 0 0 1 6 0"/>
            </svg>
            <?php if($cartCount > 0): ?>
                <span class="nav__cartn"><?php echo e($cartCount > 99 ? '99+' : $cartCount); ?></span>
            <?php endif; ?>
        </a>
        <?php if(auth()->guard()->check()): ?>
            <div class="nav__user">
                <span class="nav__avatar"><?php echo e(strtoupper(substr(auth()->user()->username, 0, 1))); ?></span>
                <span><?php echo e(auth()->user()->username); ?></span>
                <?php if(auth()->user()->isAdmin()): ?>
                    <a class="btn-out" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn-out" type="submit">Logout</button>
                </form>
            </div>
        <?php else: ?>
            <a class="btn-login" href="<?php echo e(route('login')); ?>">Login</a>
        <?php endif; ?>
    </div>
</header>
<?php /**PATH C:\fizziy\fizzify-laravel\resources\views/partials/nav.blade.php ENDPATH**/ ?>