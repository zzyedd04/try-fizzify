<?php
    $flashType = session('error') || $errors->any() ? 'error' : 'ok';
    $flashMsg = session('error') ?? session('success') ?? session('info') ?? $errors->first();
?>
<div id="toast" class="toast <?php echo e($flashType === 'error' ? 'is-error' : ''); ?>" data-msg="<?php echo e($flashMsg); ?>"></div>
<?php /**PATH C:\fizziy\fizzify-laravel\resources\views/partials/flash.blade.php ENDPATH**/ ?>